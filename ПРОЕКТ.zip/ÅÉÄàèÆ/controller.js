const bcrypt = require('bcryptjs');

module.exports = (sequelize, Sequelize) => {
    const User = sequelize.define("users", {
      Name: {
        type: Sequelize.STRING
      },
      Numberphone: {
        type: Sequelize.STRING
      },
      Email: {
        type: Sequelize.STRING
      },
      password: {
        type: Sequelize.STRING
      },
      Admin: {
        type: Sequelize.BOOLEAN
      }
    });
  
    return User;
  };


class controller{
    async registration(req, res){
        try{
            const {name, numberphone, email, password} = req.body;
            const cundidat = await User.findOne({numberphone});
            if (cundidat){
                return console.log('Пользователь стаким номером существует')
            }
            const admin = true;
            const hashPassword = bcrypt.hashSync(password, 7);
            const user = new User({name, numberphone, email, password: hashPassword, admin})
            await user.save();
        }
        catch (e) {
            console.log(e);
            res.stutus(400).json({message: "error"});
        }
    }
    async login(req, res){
        try{

        }
        catch (e) {

        }
    }
}

module.exports = new controller();