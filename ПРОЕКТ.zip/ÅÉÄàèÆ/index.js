const express = require('express');
const sqlite3 = require('sqlite3');
const cookieSession = require("cookie-session");
const cors = require("cors");
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const cookieParser = require('cookie-parser');
const passport = require('passport');
const JwtStrategy = require('passport-jwt').Strategy;
const ExtractJwt = require('passport-jwt').ExtractJwt;
const bodyParser = require('body-parser');


const port = 3000;
const server = express();
server.use(cors());
server.use(express.json());
server.use(express.urlencoded({ extended: true }));
server.use(express.static('public'));
server.use(cookieParser());
server.set('view engine', 'ejs');
let token;

//ПОДКЛЮЧЕНИЕ К БАЗЕ ДАННЫХ
const db = new sqlite3.Database('sweetShops.db', sqlite3.OPEN_READWRITE, (err)=>{
    if(err) return console.error(err.message);
});

// МОДЕЛЬ
 (sequelize, Sequelize) => {
    const User = sequelize.define("users", {
      id: {
        type: Sequelize.INTEGER
      },
      Name: {
        type: Sequelize.STRING
      },
      Numberphone: {
        type: Sequelize.STRING
      },
      Email: {
        type: Sequelize.STRING
      },
      Password: {
        type: Sequelize.STRING
      },
      Admin: {
        type: Sequelize.BOOLEAN
      }
    });
  
    return User;
  }



// Функция создания токена
const generateAccessToken = (id, admin) => {
  const payload = {
    id,
    admin
  }
  return jwt.sign(payload, 'SECRET_KEY', {expiresIn: "24h"});
}


server.listen(port, () => {
    console.log(`Server listen: ${port}`);
});


// GET ЗАПРОСЫ

//Главная страница
server.get('/', (req, res) => {
    res.sendFile(__dirname + '/index.html');
});
//Каталог
// server.get('/catalog', (req, res) => {
//   const products = [
//     {
//       id: '1',
//       Name: 'Шоколадно-карамельный',
//       Cost: '1770',
//       Structure: 'Масло72% ; яйцо куриное 1С,; мука в/с; сметана 15%; сахар-песок; какао-порошок; сыр творожный; сливки 33%; сахарная пудра; темный шоколад, печенье, молочные криспы.',
//       Dascription: 'Воздушный шоколадный бисквит, крем чиз на основе бельгийского шоколада, шоколадная глазурь, карамель, жареный фундук в хрустящей карамели, печенье, шоколадные конфеты, хрустящие криспы.',
//       Category: 'Торты',
//     }
//   ];

//     res.render(__dirname + '/catalog.ejs', {products});
// });
server.get('/catalog', (req, res) => {
  res.sendFile(__dirname + '/catalog.html');
});

//Калькулятор
server.get('/designer', (req, res) => {
    res.sendFile(__dirname + '/designer.html');
});
//Карточка товара
// server.get('/product_card/:id', (req, res) => {
//    const product = {
//      id: '1',
//      Name: 'Шоколадно-карамельный',
//      Cost: '1770',
//      Structure: 'Масло72% ; яйцо куриное 1С,; мука в/с; сметана 15%; сахар-песок; какао-порошок; сыр творожный; сливки 33%; сахарная пудра; темный шоколад, печенье, молочные криспы.',
//      Dascription: 'Воздушный шоколадный бисквит, крем чиз на основе бельгийского шоколада, шоколадная глазурь, карамель, жареный фундук в хрустящей карамели, печенье, шоколадные конфеты, хрустящие криспы.',
//      Category: 'Торты',
//    };
//     res.render(__dirname + '/product_card.ejs',{ Name, Cost, Structure, Dascription, Category});
// });
server.get('/product_card', (req, res) => {
  res.sendFile(__dirname + '/product_card.html');
});

//Страница регистрации
server.get('/registration', (req, res) => {
    res.sendFile(__dirname + '/registration.html');
});
//Страница авторизации
server.get('/authorization',  (req, res) => {
  res.sendFile(__dirname + '/authorization.html');
});


// POST ЗАПРОСЫ

//Запрос на регистрацию
server.post('/registration', (req, res) =>{
    let body = [];
    req.on('data', (chunk) => {
        body.push(chunk);
    })
    .on('end', () => {
        body = Buffer.concat(body).toString();

        let requestObject = JSON.parse(body);

        let now = new Date();

        const admin = false;
        const hashPassword = bcrypt.hashSync(requestObject.password, 7);

        db.run('INSERT INTO User (Name, Numberphone, Email, Password, Admin) VALUES (?,?,?,?,?)', requestObject.name, requestObject.numberphone, requestObject.email, hashPassword, admin );

        res.statusCode = 200;
        res.setHeader('Content-Type', 'text/plain;charset=utf-8');
        res.end();
})
});

//Запрос на авторизацию
server.post('/authorization', (req, res) =>{
  const phone = req.body.phone;
  const passwd = req.body.password;
  db.all('SELECT * FROM User WHERE Numberphone = ?', phone, (err, result) => {

    for( var i = 0; i < result.length; i++ ){
      const password = result[i]['Password'];
      const id = result[i];
        if ( bcrypt.compareSync(passwd, password)){
        const id = result[i]['id'];
        const admin = result[i]['Admin'];
        token = generateAccessToken(id, admin);
        console.log(token);
        //res.setHeader('Authorization', 'Bearer '+ token);
        res.cookie('Authorization', token, {maxAge: 1440000});
        res.redirect('/personal_account')
     
      }
      else{
        console.log('пользователь не найден');
      }
    }
  });
});

//Verifing the Token
function verifyToken(req, res, next) {
  // Get auth header value
  const bearerHeader = req.cookies['Authorization'];
  // Check if bearer is undefined
  if (typeof bearerHeader !== 'undefined') {
      // Spliting the bearer
      const bearer = bearerHeader.split(' ');
      // Get token from array
      const bearerToken = bearer[1];
      // Set the token
      req.token = bearerToken;
      // Next middleware
      next();

  } else {
      // Forbid the route
      console.log(res.sendStatus(403));
  }

}

//Личный кабинет пользователя
server.get('/personal_account', (req, res) => {

  jwt.verify(req.cookies['Authorization'], 'SECRET_KEY', (err, authData) => {
    if (err) {
        res.sendStatus(403);
    } else {
        res.sendFile(__dirname + '/personal_account.html'); 
    }
});

  
});

